# Kibana 常用功能

## Management

## Dev Tools

## Discover

  

